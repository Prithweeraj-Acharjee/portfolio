# Studio Ecosystem | Immersive AI Art Prototype

**Studio Ecosystem** is a cinematic, immersive "digital twin" prototype for a collaborative AI art experience. Virtual robot artists live in a 3D-perspective room gallery, generating generative art in real-time on the walls and floor as they move.

## 🎨 Project Overview
This prototype is designed to pitch a large-scale physical installation where real robots paint on LED walls/floors. This PC version demonstrates:
- **Perspective Room View**: A stylized 2D perspective rendering of a physical space.
- **Three Artist Personas**: Each robot has a unique movement logic and visual language (Pop Printer, Neo Oracle, Cubist Engineer).
- **Interactive Environment**: The audience (you) can direct the robots and influence the show flow.
- **Timed Show Loop**: An automated lifecycle from sparse beginnings to a unified "Final Mural."

## 🚀 How to Run

### 1. Prerequisites
- **Python 3.8+** must be installed on your system.
- **Pygame** library.

### 2. Installation
Install the necessary dependency via terminal:
```bash
pip install -r requirements.txt
```

### 3. Execution
Run the main script:
```bash
python studio_ecosystem.py
```

## 🎮 Controls
- **Mouse Click (Hold)**: Direct/Follow. Click anywhere to lead the robots with your cursor.
- **C**: **Calm Mode** (Slow, rhythmic, lower density).
- **X**: **Chaos Mode** (Fast, expressive, high density).
- **1, 2, 3**: **Boost Robot**. Increases the influence and visual footprint of a specific robot.
- **Space**: **Finalize Mural**. Jump to the final completion act.
- **R**: **Reset**. Restarts the show show from Act 1.
- **H**: Toggle **Help Overlay**.
- **ESC**: Exit.

## 📂 File Structure
- `studio_ecosystem.py`: The main simulation and rendering engine.
- `README.md`: This guide.
- `requirements.txt`: Python dependencies.

---
*Created as a Stage 1 concept prototype for "Studio Ecosystem".*
