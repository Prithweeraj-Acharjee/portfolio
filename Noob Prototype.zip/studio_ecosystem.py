import pygame
import random
import math
import sys

# --- Configuration ---
WIDTH, HEIGHT = 1280, 720
FPS = 60
BG_COLOR = (8, 8, 10)  # Deep Charcoal Near-Black

# Simulation Bounds (Internal)
SIM_W, SIM_H = 1000, 1000

# Timing (Seconds)
INTRO_DURATION = 20
INTERACT_DURATION = 30
MERGE_DURATION = 15
TOTAL_SHOW_TIME = INTRO_DURATION + INTERACT_DURATION + MERGE_DURATION

# Colors
CLR_POP = (255, 40, 150)       # Magenta/Pink
CLR_ORACLE = (0, 255, 230)      # Cyan/Turquoise
CLR_ENGINEER = (255, 180, 50)    # Amber/Gold (Soft Electric Blue option was considered, Amber feels more "Engineer")
CLR_SURFACE = (15, 15, 18)
CLR_GRID = (30, 30, 35)

# --- Classes ---

class InternalSim:
    """Hidden 2D simulation space"""
    def __init__(self):
        self.width = SIM_W
        self.height = SIM_H

class ArtistRobot:
    def __init__(self, name, x, y, color):
        self.name = name
        self.pos = pygame.Vector2(x, y)
        self.color = color
        self.base_speed = 2
        self.speed = self.base_speed
        self.angle = random.uniform(0, math.pi * 2)
        self.target_angle = self.angle
        self.move_state = "CALM"
        self.boost = 1.0
        self.pause_timer = 0
        
    def update(self, mode_speed_mult):
        if self.pause_timer > 0:
            self.pause_timer -= 1
            return
            
        # Movement Logic
        speed = self.speed * mode_speed_mult * self.boost
        
        # Smooth turn toward target angle
        diff = (self.target_angle - self.angle + math.pi) % (math.pi * 2) - math.pi
        self.angle += diff * 0.05
        
        vel = pygame.Vector2(math.cos(self.angle), math.sin(self.angle)) * speed
        self.pos += vel
        
        # Sim boundaries
        if self.pos.x < 0 or self.pos.x > SIM_W:
            self.target_angle = math.pi - self.target_angle
            self.pos.x = max(0, min(SIM_W, self.pos.x))
        if self.pos.y < 0 or self.pos.y > SIM_H:
            self.target_angle = -self.target_angle
            self.pos.y = max(0, min(SIM_H, self.pos.y))

class RoomCanvas:
    """Stores the artwork for each surface"""
    def __init__(self):
        # We use large surfaces and scale them into the trapezoids
        self.wall_size = (600, 600)
        self.floor_size = (800, 800)
        
        self.surfaces = {
            "left": pygame.Surface(self.wall_size, pygame.SRCALPHA),
            "back": pygame.Surface(self.wall_size, pygame.SRCALPHA),
            "right": pygame.Surface(self.wall_size, pygame.SRCALPHA),
            "floor": pygame.Surface(self.floor_size, pygame.SRCALPHA)
        }
        for s in self.surfaces.values():
            s.fill((0, 0, 0, 0))

    def clear(self):
        for s in self.surfaces.values():
            s.fill((0, 0, 0, 0))

class MarkEngine:
    """Generates marks based on robot state"""
    @staticmethod
    def draw_pop(canvas, robot, sim_pos):
        # Rhythmic motifs
        if random.random() < 0.15:
            surface, local_pos = MarkEngine.map_to_surface(canvas, sim_pos, "pop")
            size = random.randint(10, 25)
            alpha = int(100 * robot.boost)
            color = list(robot.color) + [alpha]
            
            if random.random() < 0.7:
                pygame.draw.circle(surface, color, local_pos, size, 2)
            else:
                rect = pygame.Rect(0, 0, size*1.5, size*1.5)
                rect.center = local_pos
                pygame.draw.rect(surface, color, rect, 2)

    @staticmethod
    def draw_oracle(canvas, robot, sim_pos):
        # Expressive scribbles
        surface, local_pos = MarkEngine.map_to_surface(canvas, sim_pos, "oracle")
        if random.random() < 0.4:
            alpha = int(60 * robot.boost)
            points = []
            for _ in range(3):
                offset = pygame.Vector2(random.uniform(-15, 15), random.uniform(-15, 15))
                points.append(local_pos + offset)
            if len(points) > 1:
                pygame.draw.lines(surface, list(robot.color) + [alpha], False, points, 1)

    @staticmethod
    def draw_engineer(canvas, robot, sim_pos):
        # Cubic fragments
        if random.random() < 0.1:
            surface, local_pos = MarkEngine.map_to_surface(canvas, sim_pos, "engineer")
            alpha = int(80 * robot.boost)
            size = random.randint(20, 50)
            angle = random.uniform(0, math.pi)
            p1 = local_pos + pygame.Vector2(math.cos(angle), math.sin(angle)) * size
            p2 = local_pos + pygame.Vector2(math.cos(angle + 2), math.sin(angle + 2)) * size
            p3 = local_pos + pygame.Vector2(math.cos(angle + 4), math.sin(angle + 4)) * size
            pygame.draw.polygon(surface, list(robot.color) + [alpha], [p1, p2, p3], 1)

    @staticmethod
    def map_to_surface(canvas, sim_pos, style):
        """Hidden Sim -> Perspective Surface Mapping"""
        # Determine target surface based on X
        # Left wall (0-333), Back wall (333-666), Right wall (666-1000)
        
        # Floor gets marks from everywhere
        if random.random() < 0.4:
            target = "floor"
            local_x = (sim_pos.x / SIM_W) * canvas.floor_size[0]
            local_y = (sim_pos.y / SIM_H) * canvas.floor_size[1]
            return canvas.surfaces[target], (int(local_x), int(local_y))
            
        if sim_pos.x < 333:
            target = "left"
            local_x = (sim_pos.x / 333) * canvas.wall_size[0]
        elif sim_pos.x < 666:
            target = "back"
            local_x = ((sim_pos.x - 333) / 333) * canvas.wall_size[0]
        else:
            target = "right"
            local_x = ((sim_pos.x - 666) / 334) * canvas.wall_size[0]
            
        local_y = (sim_pos.y / SIM_H) * canvas.wall_size[1]
        return canvas.surfaces[target], (int(local_x), int(local_y))

class RoomRenderer:
    """Renders the 2D surfaces into a perspective view"""
    def __init__(self):
        # Perspective Geometry Points
        # Defined as relative to screen center
        cx, cy = WIDTH // 2, HEIGHT // 2
        
        # Back Wall (Square in center)
        bh = 300
        self.back_rect = pygame.Rect(cx - bh, cy - bh//1.5, bh*2, bh*2//1.2)
        
        # Geometry for wall/floor corners
        self.pts = {
            "nw": (self.back_rect.left, self.back_rect.top),
            "ne": (self.back_rect.right, self.back_rect.top),
            "sw": (self.back_rect.left, self.back_rect.bottom),
            "se": (self.back_rect.right, self.back_rect.bottom),
            "screen_nw": (0, 0),
            "screen_ne": (WIDTH, 0),
            "screen_sw": (100, HEIGHT),
            "screen_se": (WIDTH-100, HEIGHT)
        }

    def draw(self, screen, canvas, sim_robots, show_merge, merge_prog):
        # 1. Draw Static Room Structure (Shadows/Lines)
        screen.fill(BG_COLOR)
        
        # Surfaces
        # Floor
        pygame.draw.polygon(screen, CLR_SURFACE, [self.pts["sw"], self.pts["se"], self.pts["screen_se"], self.pts["screen_sw"]])
        # Walls
        pygame.draw.polygon(screen, (12, 12, 15), [self.pts["screen_nw"], self.pts["nw"], self.pts["sw"], (0, HEIGHT)]) # Left
        pygame.draw.polygon(screen, (12, 12, 15), [self.pts["screen_ne"], self.pts["ne"], self.pts["se"], (WIDTH, HEIGHT)]) # Right
        pygame.draw.rect(screen, (18, 18, 22), self.back_rect) # Back
        
        # Outline
        pygame.draw.line(screen, CLR_GRID, self.pts["nw"], self.pts["screen_nw"], 1)
        pygame.draw.line(screen, CLR_GRID, self.pts["sw"], (0, HEIGHT), 1)
        pygame.draw.line(screen, CLR_GRID, self.pts["ne"], self.pts["screen_ne"], 1)
        pygame.draw.line(screen, CLR_GRID, self.pts["se"], (WIDTH, HEIGHT), 1)
        pygame.draw.rect(screen, CLR_GRID, self.back_rect, 1)

        # 2. Project Canvases (Simple Warping using pygame.transform.smoothscale for back, 
        # for walls we use surface shearing or just trapezoidal drawing logic)
        
        # Back Wall is direct
        back_surf = pygame.transform.smoothscale(canvas.surfaces["back"], (self.back_rect.width, self.back_rect.height))
        screen.blit(back_surf, self.back_rect.topleft)
        
        # For simplicity in Pygame without heavy GL math, we draw the "warped" marks 
        # by manually projecting points or using a helper. 
        # Here we will use a "Style Projection": we render the surfaces as they are, 
        # but the canvas mapping already accounts for some spatial logic.
        
        # Real-time Robot Indicators (Small glowing dots in perspective)
        if not show_merge:
            for r in sim_robots:
                proj_x, proj_y = self.get_projected_pos(r.pos)
                pygame.draw.circle(screen, r.color, (int(proj_x), int(proj_y)), 4)
                glow = pygame.Surface((20, 20), pygame.SRCALPHA)
                pygame.draw.circle(glow, list(r.color) + [50], (10, 10), 8)
                screen.blit(glow, (proj_x - 10, proj_y - 10), special_flags=pygame.BLEND_ADD)

        # We also blit the other walls with a simple perspective "squish"
        # Since standard Pygame blit doesn't do trapezoids, we'll draw the generated marks 
        # directly in the main loop using the projection logic for better visual quality.
        # (Self-correction: drawing thousands of marks in loops is slow, so we keep the surfaces 
        # and blit them. To stay "Standard Lib only", we'll accept approximate rectangular blits 
        # for side walls but mask them to trapezoids.)
        
        self.blit_side_walls(screen, canvas)

        # 3. Final Merge Pulse
        if show_merge:
            pulse = pygame.Surface((WIDTH, HEIGHT))
            pulse.fill((255, 255, 255))
            pulse.set_alpha(int(merge_prog * 100))
            screen.blit(pulse, (0,0), special_flags=pygame.BLEND_ADD)
            
            # Vignette intensify
            v = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            pygame.draw.circle(v, (0, 0, 0, 150), (WIDTH//2, HEIGHT//2), WIDTH)
            screen.blit(v, (0,0))

    def blit_side_walls(self, screen, canvas):
        # Left wall mask/blit
        lw = self.pts["nw"][0]
        lh = self.pts["sw"][1] - self.pts["nw"][1]
        ls = pygame.transform.smoothscale(canvas.surfaces["left"], (lw, lh))
        screen.blit(ls, (0, self.pts["nw"][1]))
        
        # Right wall mask/blit
        rw = WIDTH - self.pts["ne"][0]
        rs = pygame.transform.smoothscale(canvas.surfaces["right"], (rw, lh))
        screen.blit(rs, (self.pts["ne"][0], self.pts["ne"][1]))

        # Floor blit
        fs = pygame.transform.smoothscale(canvas.surfaces["floor"], (WIDTH, HEIGHT - self.pts["sw"][1]))
        screen.blit(fs, (0, self.pts["sw"][1]))

    def get_projected_pos(self, sim_pos):
        """Map sim x,y to screen x,y in perspective"""
        # Linear interp for simplicity that looks 'convincing'
        x_norm = sim_pos.x / SIM_W
        y_norm = sim_pos.y / SIM_H
        
        # Horizon is at back wall top
        horizon_y = self.pts["nw"][1]
        front_y = HEIGHT
        
        screen_y = horizon_y + (y_norm * (front_y - horizon_y))
        
        # X depends on depth (y)
        # Narrower at top, wider at bottom
        width_at_y = self.pts["ne"][0] - self.pts["nw"][0] 
        # Increase width as we get closer
        width_at_y *= (1 + y_norm * 0.5) 
        
        center_x = WIDTH // 2
        screen_x = center_x + (x_norm - 0.5) * width_at_y
        
        return screen_x, screen_y

# --- Main Logic ---

class ShowController:
    def __init__(self):
        self.state = "INTRO"
        self.timer = 0
        self.mode = "CALM"
        self.boosted = None
        self.show_help = False
        self.final_text_timer = 0
        
    def update(self):
        self.timer += 1/FPS
        if self.state == "INTRO" and self.timer > INTRO_DURATION:
            self.state = "INTERACTION"
        elif self.state == "INTERACTION" and self.timer > INTRO_DURATION + INTERACT_DURATION:
            self.state = "MERGE"
        elif self.state == "MERGE" and self.timer > TOTAL_SHOW_TIME:
            self.final_text_timer = 300 # 5 seconds
            self.state = "FINISHED"

class UIOverlay:
    def __init__(self):
        self.font = pygame.font.SysFont("Arial", 14)
        self.title_font = pygame.font.SysFont("Arial", 28, bold=True)
        
    def draw(self, screen, controller):
        # Top-Left Panel
        panel = pygame.Surface((220, 100), pygame.SRCALPHA)
        panel.fill((20, 20, 25, 180))
        screen.blit(panel, (20, 20))
        
        y_off = 30
        lines = [
            f"MODE: {controller.mode}",
            f"BOOST: {controller.boosted if controller.boosted else 'NONE'}",
            f"ACT: {controller.state}"
        ]
        for line in lines:
            txt = self.font.render(line.upper(), True, (200, 200, 200))
            screen.blit(txt, (40, y_off))
            y_off += 20
            
        hint = self.font.render("PRESS 'H' FOR HELP", True, (100, 100, 100))
        screen.blit(hint, (40, 130))

        if controller.show_help:
            help_p = pygame.Surface((300, 200), pygame.SRCALPHA)
            help_p.fill((10, 10, 10, 230))
            screen.blit(help_p, (WIDTH//2 - 150, HEIGHT//2 - 100))
            h_lines = [
                "1, 2, 3 : Boost Robot",
                "C : Calm Mode",
                "X : Chaos Mode",
                "SPACE : Manual Merge",
                "R : Reset Show",
                "ESC : Exit"
            ]
            for i, l in enumerate(h_lines):
                t = self.font.render(l, True, (255, 255, 255))
                screen.blit(t, (WIDTH//2 - 130, HEIGHT//2 - 80 + i*25))

        if controller.state == "FINISHED" or controller.final_text_timer > 0:
            txt = self.title_font.render("FINAL MURAL GENERATED", True, (255, 255, 255))
            screen.blit(txt, (WIDTH//2 - txt.get_width()//2, HEIGHT//2))
            controller.final_text_timer -= 1

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Studio Ecosystem | Immersive Digital Twin")
    clock = pygame.time.Clock()
    
    # Engines
    canvas = RoomCanvas()
    renderer = RoomRenderer()
    ctrl = ShowController()
    ui = UIOverlay()
    
    robots = [
        ArtistRobot("Pop Printer", 200, 500, CLR_POP),
        ArtistRobot("Neo Oracle", 500, 500, CLR_ORACLE),
        ArtistRobot("Cubist Engineer", 800, 500, CLR_ENGINEER)
    ]
    
    running = True
    while running:
        # 1. IO
        mouse_pos = pygame.Vector2(pygame.mouse.get_pos())
        mouse_pressed = pygame.mouse.get_pressed()[0]
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: running = False
                if event.key == pygame.K_h: ctrl.show_help = not ctrl.show_help
                if event.key == pygame.K_c: ctrl.mode = "CALM"
                if event.key == pygame.K_x: ctrl.mode = "CHAOS"
                if event.key == pygame.K_1: ctrl.boosted = "POP"
                if event.key == pygame.K_2: ctrl.boosted = "ORACLE"
                if event.key == pygame.K_3: ctrl.boosted = "ENGINEER"
                if event.key == pygame.K_r: 
                    ctrl = ShowController()
                    canvas.clear()
                if event.key == pygame.K_SPACE: ctrl.state = "MERGE"

        # 2. Logic
        ctrl.update()
        speed_mult = 1.0 if ctrl.mode == "CALM" else 2.5
        
        for r in robots:
            # Handle Boosting
            r.boost = 2.0 if ctrl.boosted == r.name.split()[0].upper() else 1.0
            
            # MOUSE INTERACTION: Influence robots toward cursor if clicked or near
            if mouse_pressed:
                # We need to map screen mouse pos back to sim pos for influence
                # This is complex, so we'll just check if the projected robot pos is near mouse
                proj_x, proj_y = renderer.get_projected_pos(r.pos)
                diff = pygame.Vector2(proj_x, proj_y) - mouse_pos
                if diff.length() < 300: # Influence radius
                    r.target_angle = math.atan2(-diff.y, -diff.x)
                    r.speed = 10 if ctrl.mode == "CHAOS" else 5
            else:
                r.speed = r.base_speed
            
            # Special Intro Behaviors (Keep them in zones)
            if ctrl.state == "INTRO":
                # Only restrict if not manually influenced
                if not mouse_pressed:
                    if r.name == "Pop Printer" and r.pos.x > 333: r.target_angle = math.pi
                    if r.name == "Neo Oracle" and (r.pos.x < 333 or r.pos.x > 666): 
                        r.target_angle = 0 if r.pos.x < 333 else math.pi
                    if r.name == "Cubist Engineer" and r.pos.x < 666: r.target_angle = 0
            elif ctrl.state == "MERGE":
                center = pygame.Vector2(SIM_W//2, SIM_H//2)
                diff = center - r.pos
                if diff.length() > 5:
                    r.angle = math.atan2(diff.y, diff.x)
                else:
                    if not mouse_pressed: r.speed = 0
            
            # Random wandering
            if not mouse_pressed and random.random() < 0.05:
                r.target_angle += random.uniform(-0.5, 0.5)

            r.update(speed_mult)
            
            # 3. Generate Marks (Polished Styles)
            if ctrl.state != "FINISHED":
                if r.name == "Pop Printer": 
                    # Repeated Motifs
                    if random.random() < (0.2 * speed_mult):
                        surface, local_pos = MarkEngine.map_to_surface(canvas, r.pos, "pop")
                        size = random.randint(15, 30)
                        color = list(r.color) + [80 if r.boost > 1 else 40]
                        if random.random() < 0.8:
                            pygame.draw.circle(surface, color, local_pos, size, 1)
                        else:
                            # Halftone cluster
                            for _ in range(5):
                                off = (random.randint(-10, 10), random.randint(-10, 10))
                                pygame.draw.circle(surface, color, (local_pos[0]+off[0], local_pos[1]+off[1]), 3)

                elif r.name == "Neo Oracle": 
                    # Expressive Scribbles
                    if random.random() < (0.5 * speed_mult):
                        surface, local_pos = MarkEngine.map_to_surface(canvas, r.pos, "oracle")
                        color = list(r.color) + [60 if r.boost > 1 else 30]
                        points = [local_pos]
                        for i in range(2):
                            points.append(points[-1] + pygame.Vector2(random.uniform(-20, 20), random.uniform(-20, 20)))
                        pygame.draw.lines(surface, color, False, points, 2)

                elif r.name == "Cubist Engineer": 
                    # Geometric Slices
                    if random.random() < (0.15 * speed_mult):
                        surface, local_pos = MarkEngine.map_to_surface(canvas, r.pos, "engineer")
                        color = list(r.color) + [100 if r.boost > 1 else 50]
                        size = random.randint(30, 60)
                        pts = []
                        for _ in range(3):
                            pts.append(local_pos + pygame.Vector2(random.uniform(-size, size), random.uniform(-size, size)))
                        pygame.draw.polygon(surface, color, pts, 1)

        # 4. Render
        merge_prog = 0
        if ctrl.state == "MERGE":
            merge_prog = (ctrl.timer - (INTRO_DURATION + INTERACT_DURATION)) / MERGE_DURATION
            
        renderer.draw(screen, canvas, robots, ctrl.state == "MERGE", merge_prog)
        ui.draw(screen, ctrl)
        
        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
